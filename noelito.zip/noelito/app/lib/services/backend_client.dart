import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/models.dart';

/// Cliente hacia el backend proxy de Noelito.
/// La API key de Anthropic vive SOLO en el backend, nunca aquí.
class BackendClient {
  // ⚙️ Cambia esto por tu URL de Railway cuando despliegues.
  // Para pruebas locales con el teléfono en la misma red: http://<IP-de-tu-PC>:3000
  static const String baseUrl = 'http://192.168.1.100:3000';

  Future<AssistantResult> chat(List<ChatMessage> history) async {
    final resp = await http
        .post(
          Uri.parse('$baseUrl/chat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'messages': history.map((m) => m.toJson()).toList(),
          }),
        )
        .timeout(const Duration(seconds: 30));

    if (resp.statusCode != 200) {
      throw Exception('Backend respondió ${resp.statusCode}: ${resp.body}');
    }
    return AssistantResult.fromJson(
        jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>);
  }
}
