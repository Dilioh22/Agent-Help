import Anthropic from "@anthropic-ai/sdk";
import cors from "cors";
import express from "express";

const app = express();
app.use(cors());
app.use(express.json());

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MODEL = process.env.NOELITO_MODEL ?? "claude-haiku-4-5-20251001";

// ---------- Herramientas que Noelito puede ejecutar en el teléfono ----------
const tools: Anthropic.Tool[] = [
  {
    name: "set_alarm",
    description: "Crea una alarma en el teléfono a una hora específica.",
    input_schema: {
      type: "object",
      properties: {
        hour: { type: "integer", description: "Hora en formato 24h (0-23)" },
        minute: { type: "integer", description: "Minutos (0-59)" },
        label: { type: "string", description: "Etiqueta de la alarma" },
      },
      required: ["hour", "minute"],
    },
  },
  {
    name: "set_timer",
    description: "Inicia un temporizador (cuenta regresiva).",
    input_schema: {
      type: "object",
      properties: {
        seconds: { type: "integer", description: "Duración total en segundos" },
        label: { type: "string" },
      },
      required: ["seconds"],
    },
  },
  {
    name: "open_app",
    description: "Abre una aplicación instalada en el teléfono por su nombre.",
    input_schema: {
      type: "object",
      properties: { name: { type: "string", description: "Nombre de la app, ej. 'spotify'" } },
      required: ["name"],
    },
  },
  {
    name: "call_contact",
    description: "Marca a un contacto de la agenda por nombre. La llamada requiere confirmación del usuario en pantalla.",
    input_schema: {
      type: "object",
      properties: { name: { type: "string", description: "Nombre o apodo del contacto" } },
      required: ["name"],
    },
  },
  {
    name: "send_whatsapp",
    description: "Abre un chat de WhatsApp con un contacto y el mensaje prellenado (el usuario da enviar).",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string", description: "Nombre del contacto" },
        text: { type: "string", description: "Texto del mensaje" },
      },
      required: ["name", "text"],
    },
  },
  {
    name: "create_calendar_event",
    description: "Crea un evento de calendario. Pásale los tiempos en milisegundos epoch.",
    input_schema: {
      type: "object",
      properties: {
        title: { type: "string" },
        begin_millis: { type: "number" },
        end_millis: { type: "number" },
        location: { type: "string" },
      },
      required: ["title", "begin_millis"],
    },
  },
  {
    name: "open_settings_panel",
    description: "Abre un panel de configuración del teléfono.",
    input_schema: {
      type: "object",
      properties: {
        panel: { type: "string", enum: ["wifi", "internet", "volume", "bluetooth", "settings"] },
      },
      required: ["panel"],
    },
  },
];

const SYSTEM = `Eres Noelito, el asistente personal de voz de Dilio (San Pedro Sula, Honduras).
Personalidad: servicial, directo, con calidez hondureña sutil. Nada de discursos largos.

Reglas:
- Respondes SIEMPRE en español.
- Tus respuestas se leen en voz alta (TTS): frases cortas, sin markdown, sin listas, sin emojis, sin asteriscos.
- Máximo 2-3 oraciones salvo que pidan explicación larga.
- Fecha/hora actual del servidor: {{NOW}} (zona América/Tegucigalpa).
- Si el usuario pide una acción del teléfono, usa la herramienta adecuada. Si pide algo que ninguna herramienta cubre, dilo honestamente y sugiere alternativa.
- Para eventos de calendario calcula los milisegundos epoch correctamente usando la fecha actual.
- Si te preguntan tu nombre: te llamas Noelito.`;

// ---------- Endpoint principal ----------
app.post("/chat", async (req, res) => {
  try {
    const messages = (req.body?.messages ?? []) as Anthropic.MessageParam[];
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages requerido" });
    }

    const now = new Date().toLocaleString("es-HN", { timeZone: "America/Tegucigalpa" });

    const response = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 600,
      system: SYSTEM.replace("{{NOW}}", now),
      tools,
      messages,
    });

    // ¿Pidió ejecutar una herramienta?
    const toolUse = response.content.find(
      (b): b is Anthropic.ToolUseBlock => b.type === "tool_use"
    );
    const text = response.content
      .filter((b): b is Anthropic.TextBlock => b.type === "text")
      .map((b) => b.text)
      .join(" ")
      .trim();

    if (toolUse) {
      return res.json({
        speak: text || null, // Claude puede acompañar la acción con una frase
        action: { name: toolUse.name, args: toolUse.input },
      });
    }
    return res.json({ speak: text || "No estoy seguro de cómo ayudarte con eso." });
  } catch (err: any) {
    console.error(err);
    return res.status(500).json({ error: err?.message ?? "error interno" });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, name: "noelito" }));

const PORT = Number(process.env.PORT ?? 3000);
app.listen(PORT, () => console.log(`🤖 Noelito backend escuchando en :${PORT}`));
